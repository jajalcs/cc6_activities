package com.example.prjbaguyocalcu

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
