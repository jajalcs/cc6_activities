import 'package:flutter/material.dart';
import 'calculator_button.dart';

void main() => runApp(CalculatorApp());

class CalculatorApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Calculator',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: Calculator(),
    );
  }
}

class Calculator extends StatefulWidget {
  @override
  _CalculatorState createState() => _CalculatorState();
}

class _CalculatorState extends State<Calculator> {
  TextEditingController num1Controller = TextEditingController();
  TextEditingController num2Controller = TextEditingController();
  String result = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Calculator'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            TextField(
              controller: num1Controller,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Input First Number',
                labelStyle: TextStyle(fontSize: 24.0),
              ),
              style: TextStyle(fontSize: 24.0),
            ),
            SizedBox(height: 16.0),
            TextField(
              controller: num2Controller,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Input Second Number',
                labelStyle: TextStyle(fontSize: 24.0),
              ),
              style: TextStyle(fontSize: 24.0),
            ),
            SizedBox(height: 16.0),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                CalculatorButton(
                  onPressed: () {
                    calculateResult('+');
                  },
                  icon: Icons.add,
                ),
                CalculatorButton(
                  onPressed: () {
                    calculateResult('-');
                  },
                  icon: Icons.remove,
                ),
                CalculatorButton(
                  onPressed: () {
                    calculateResult('*');
                  },
                  icon: Icons.close,
                ),
                CalculatorButton(
                  onPressed: () {
                    calculateResult('/');
                  },
                  icon: Icons.check,
                ),
              ],
            ),
            SizedBox(height: 16.0),
            Text(
              'Result: $result',
              style: TextStyle(fontSize: 22),
            ),
          ],
        ),
      ),
    );
  }

  void calculateResult(String operation) {
    double? num1 = double.tryParse(num1Controller.text);
    double? num2 = double.tryParse(num2Controller.text);
    double res = 0; // Initialize res variable

    if (num1 != null && num2 != null) {
      if (num2 != 0) {
        // Add check to prevent division by zero
        switch (operation) {
          case '+':
            res = num1 + num2;
            break;
          case '-':
            res = num1 - num2;
            break;
          case '*':
            res = num1 * num2;
            break;
          case '/':
            res = num1 / num2;
            break;
        }

        setState(() {
          result = res.toString();
        });
      } else {
        setState(() {
          result = 'Error: Division by zero';
        });
      }
    } else {
      setState(() {
        result = 'Error: Invalid input';
      });
    }
  }
}
