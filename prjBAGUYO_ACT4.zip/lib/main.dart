import 'package:flutter/material.dart';
import 'login_screen.dart';
import 'signup_screen.dart';
import 'home_screen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Login and Sign Up',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => MyHomePage(),
        '/login': (context) => LoginScreen(),
        '/signup': (context) => SignupScreen(),
        '/home': (context) => HomeScreen(),
      },
    );
  }
}

class MyHomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          CustomPaint(
            size: Size(double.infinity, double.infinity),
            painter: BackgroundPainter(),
          ),
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Stack(
                  alignment: Alignment.center,
                  children: [
                    Image.asset(
                      'assets/design.png',
                      width: 220,
                      height: 220,
                    ),
                    Positioned(
                      top: 25,
                      child: Image.asset(
                        'assets/per.png',
                        width: 150,
                        height: 150,
                      ),
                    ),
                    Positioned(
                      top: 100,
                      child: Image.asset(
                        'assets/book.png',
                        width: 120,
                        height: 120,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 16),
                Text(
                  'LEARN AND DREAM HARD!',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                SizedBox(height: 16),
                Text(
                  'Education is the passport to the future, for tomorrow belongs to those who prepare for it today',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 16,
                    fontStyle: FontStyle.italic,
                    color: Colors.white,
                  ),
                ),
                SizedBox(height: 180),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    ElevatedButton(
                      onPressed: () {
                        // Navigate to LoginScreen when Log In button is pressed
                        Navigator.pushNamed(context, '/login');
                      },
                      style: ElevatedButton.styleFrom(
                        primary: Color(0xffb162bf), // Light purple color
                        padding:
                            EdgeInsets.symmetric(horizontal: 24, vertical: 16),
                        textStyle: TextStyle(fontSize: 18),
                      ),
                      child: Text('Log In'),
                    ),
                    SizedBox(width: 16),
                    ElevatedButton(
                      onPressed: () {
                        // Navigate to SignUpScreen when Sign Up button is pressed
                        Navigator.pushNamed(context, '/signup');
                      },
                      style: ElevatedButton.styleFrom(
                        primary: Color(0xffc651da), // Light purple color
                        padding:
                            EdgeInsets.symmetric(horizontal: 24, vertical: 16),
                        textStyle: TextStyle(fontSize: 18),
                      ),
                      child: Text('Sign Up'),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class BackgroundPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final arcPaint = Paint()
      ..shader = LinearGradient(
        colors: [
          Color(0xff8f87b5),
          Color(0xffbba3f4),
          Color(0xff62508c),
        ],
        begin: Alignment.bottomCenter,
        end: Alignment.topCenter,
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));

    final backgroundPaint = Paint()
      ..color = Color(0xff773d85); // Color of the background

    final path = Path()
      ..moveTo(0, size.height * 0.8)
      ..lineTo(0, size.height)
      ..lineTo(size.width, size.height)
      ..lineTo(size.width, size.height * 0.7)
      ..quadraticBezierTo(
          size.width * 0.6, size.height * 0.6, 0, size.height * 0.7)
      ..close();

    canvas.drawRect(
        Rect.fromLTRB(0, 0, size.width, size.height), backgroundPaint);
    canvas.drawPath(path, arcPaint);
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) {
    return false;
  }
}
