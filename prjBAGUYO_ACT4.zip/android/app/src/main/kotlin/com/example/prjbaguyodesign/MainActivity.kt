package com.example.prjbaguyodesign

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
